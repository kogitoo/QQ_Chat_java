package com.qq.server.model;

import java.io.IOException;

public class StartServerThread  extends Thread{
	private MyQqServer mqs;
	public void run() {
		this.mqs=new MyQqServer();
	}
	public void end(){
		try {
			System.out.println("���ڹر�socket");
			if(MyQqServer.ss != null){
					MyQqServer.ss.close();
			}

			System.out.println("socket�رճɹ�");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("mqs.end().e1");
		}
	}
	
}
