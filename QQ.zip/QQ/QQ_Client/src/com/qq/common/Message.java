
package com.qq.common;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Message implements java.io.Serializable{
	private String mesType;
	private String sender;
	private String getter;
	private String sendTime;
	private String con;
	private ImageIcon pic;
	private File file;
	private String fileName;
	private byte[] fileByte;
	
	public byte[] getFileByte() {
		return fileByte;
	}
	public void setFileByte(byte[] fileByte) {
		this.fileByte = fileByte;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		//����ֱ�Ӹ�ֵ������Ӧ�ý������ļ�������ʽ����Message������
		this.file = file;
	}
	public ImageIcon getPic() {
		return pic;
	}
	public void setPic(ImageIcon pic) {
		this.pic = pic;
	}
	public String getMesType() {
		return mesType;
	}
	public void setMesType(String mesType) {
		this.mesType = mesType;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getGetter() {
		return getter;
	}
	public void setGetter(String getter) {
		this.getter = getter;
	}
	public String getCon() {
		return con;
	}
	public void setCon(String con) {
		this.con = con;
	}
	public String getSendTime() {
		return sendTime;
	}
	public void setSendTime(String sendTime) {
		this.sendTime = sendTime;
	}
	
	
}
